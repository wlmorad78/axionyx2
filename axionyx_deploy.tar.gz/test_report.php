<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$txn = \App\Models\InventoryTransaction::with(['transactionType','warehouse'])->where('id',38)->first();
echo "txn_type: " . ($txn->transactionType?->code ?? 'null') . " effect: " . ($txn->transactionType?->effect ?? 'null') . PHP_EOL;

$items = $txn->items->where('item_id', 2);
foreach($items as $i) {
    echo "item_id: " . $i->item_id . " qty: " . $i->qty . PHP_EOL;
}

// Simulate the report
$obQuery = \App\Models\InventoryOpeningBalance::query()
    ->where('item_id', 2)
    ->where('company_id', 2);

$openingBalances = $obQuery->get();
$openingQty = 0;
foreach ($openingBalances as $ob) {
    $openingQty += (float)$ob->qty;
}
echo "opening_qty: " . $openingQty . PHP_EOL;

$runningBalance = $openingQty;
foreach ($items as $txnItem) {
    $qty = (float)$txnItem->qty;
    $isAddition = $txn->transactionType?->effect === 'addition';
    $qtyIn = $isAddition ? abs($qty) : 0;
    $runningBalance += $qty;
    echo "qty_in: " . $qtyIn . " running_balance: " . $runningBalance . PHP_EOL;
}
echo "final_balance: " . $runningBalance . PHP_EOL;

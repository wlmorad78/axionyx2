<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$itemId = 2;
$companyId = 2;

// Simulate the API logic
$openingBalances = \App\Models\InventoryOpeningBalance::where('item_id', $itemId)
    ->where('company_id', $companyId)->get();
$openingQty = 0;
foreach ($openingBalances as $ob) {
    $conversionFactor = 1;
    if (!empty($ob->unit_id)) {
        $iu = \App\Models\ItemUnit::where('item_id', $itemId)->where('unit_id', $ob->unit_id)->first();
        if ($iu && $iu->conversion_factor > 0) $conversionFactor = $iu->conversion_factor;
    }
    $openingQty += (float)$ob->qty * $conversionFactor;
}

$txns = \App\Models\InventoryTransaction::query()
    ->whereHas('items', function($q) use ($itemId) { $q->where('item_id', $itemId); })
    ->where('status', 'posted')
    ->where('company_id', $companyId)
    ->with(['transactionType', 'items'])
    ->get();

$runningBalance = $openingQty;
echo "Opening: $openingQty\n\n";

foreach ($txns as $txn) {
    foreach ($txn->items->where('item_id', $itemId) as $txnItem) {
        $qty = (float)$txnItem->qty;
        $effect = $txn->transactionType?->effect ?? '';
        $refShort = $txn->reference_type ? class_basename($txn->reference_type) : '';
        $isReturnType = (stripos($refShort, 'return') !== false);
        $typeName = $txn->transactionType?->name ?? '';

        echo "TXN {$txn->id}: ref=$refShort, effect=$effect, qty=$qty\n";

        $qtyIn = 0; $qtyOut = 0; $qtyLoad = 0; $qtyReturn = 0;

        if ($isReturnType) {
            $qtyReturn = abs($qty);
        } else {
            $isIssueOrder = ($refShort === 'IssueOrder');
            $qtyIn = ($effect === 'addition') ? abs($qty) : 0;
            $qtyOut = ($effect === 'subtraction' && !$isIssueOrder) ? abs($qty) : 0;
            $qtyLoad = ($effect === 'subtraction' && $isIssueOrder) ? abs($qty) : 0;
        }

        $runningBalance += $qty;
        echo "  -> qtyIn=$qtyIn, qtyOut=$qtyOut, qtyLoad=$qtyLoad, qtyReturn=$qtyReturn, balance=$runningBalance\n";
    }
}

echo "\nFinal balance: $runningBalance\n";

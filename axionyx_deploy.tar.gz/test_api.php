<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

$itemId = 2;

$txns = \App\Models\InventoryTransaction::query()
    ->whereHas('items', function($q) use ($itemId) { $q->where('item_id', $itemId); })
    ->where('status', 'posted')
    ->with(['items', 'transactionType'])
    ->get();

echo "=== Transactions ===\n";
foreach ($txns as $t) {
    echo "ID: {$t->id}, status: {$t->status}, type: {$t->transactionType?->name}, effect: {$t->transactionType?->effect}\n";
    foreach ($t->items->where('item_id', $itemId) as $item) {
        echo "  item qty={$item->qty}, cf={$item->conversion_factor}, bq={$item->base_quantity}\n";
    }
}

$openingBalances = \App\Models\InventoryOpeningBalance::where('item_id', $itemId)->get();
echo "\n=== Opening Balances ===\n";
foreach ($openingBalances as $ob) {
    echo "ID: {$ob->id}, qty: {$ob->qty}, unit_id: {$ob->unit_id}, company_id: {$ob->company_id}\n";
}
